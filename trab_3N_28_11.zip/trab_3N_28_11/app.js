const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3005; // Mudança para a porta 3005

// Adiciona o CORS
app.use(cors());

app.get('/', (req, res) => {
  res.send('Juiz de Fora 21°C');
});

app.get('/temperatura', (req, res) => {
  const cidade = 'Juiz de Fora';
  const temperatura = 21; // Temperatura fixa em 23 graus Celsius
  res.json({ mensagem: `${cidade} ${temperatura}°C` });
});

app.listen(PORT, () => {
  console.log(`Servidor está rodando na porta ${PORT}`);
});
