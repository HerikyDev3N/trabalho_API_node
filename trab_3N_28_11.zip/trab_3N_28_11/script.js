document.addEventListener('DOMContentLoaded', function() {
    const weatherBox = document.getElementById('weather-box');
    const cityNameElement = document.getElementById('city-name');
    const temperatureElement = document.getElementById('temperature');
  
    // Substitua a URL pela URL do seu servidor Node.js
    const apiUrl = 'http://localhost:3005/temperatura';
  
    fetch(apiUrl)
      .then(response => response.text())  // Alteração aqui: usar response.text() para obter a string diretamente
      .then(data => {
        // Verificar se a string contém um formato esperado antes de tentar extrair os dados
        const regexResult = /([\w\s]+)\s(\d+)°C/.exec(data);
        if (regexResult && regexResult.length === 3) {
          const cidade = regexResult[1];
          const temperatura = regexResult[2];
  
          cityNameElement.textContent = cidade;
          temperatureElement.textContent = `${temperatura}°C`;
        } else {
          cityNameElement.textContent = 'Dados meteorológicos inválidos';
          temperatureElement.textContent = '--°C';
        }
      })
      .catch(error => {
        console.error('Erro ao obter dados meteorológicos:', error);
        cityNameElement.textContent = 'Erro ao obter dados meteorológicos';
        temperatureElement.textContent = '--°C';
      });
  });
  